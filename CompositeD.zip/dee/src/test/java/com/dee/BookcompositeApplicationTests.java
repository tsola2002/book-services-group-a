package com.dee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookcompositeApplicationTests {

	@Test
	void contextLoads() {
	}

}
