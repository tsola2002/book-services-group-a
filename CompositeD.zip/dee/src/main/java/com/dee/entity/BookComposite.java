package com.dee.entity;

public class BookComposite {
    private Long productId;
    private String productName;
    private double productPrice;
    private String[] reviews;
    private String[] recommendations;

    public BookComposite() {}

    public BookComposite(Long productId, String productName, double productPrice, String[] reviews, String[] recommendations) {
        this.productId = productId;
        this.productName = productName;
        this.productPrice = productPrice;
        this.reviews = reviews;
        this.recommendations = recommendations;
    }

    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }
    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }
    public double getProductPrice() { return productPrice; }
    public void setProductPrice(double productPrice) { this.productPrice = productPrice; }
    public String[] getReviews() { return reviews; }
    public void setReviews(String[] reviews) { this.reviews = reviews; }
    public String[] getRecommendations() { return recommendations; }
    public void setRecommendations(String[] recommendations) { this.recommendations = recommendations; }
}