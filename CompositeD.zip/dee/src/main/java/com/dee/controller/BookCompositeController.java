package com.dee.controller;

import com.dee.entity.BookComposite;
import com.dee.service.BookCompositeService;
import java.util.List;

import com.dee.service.RestApiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/composite")
public class BookCompositeController {
    @Autowired
    private BookCompositeService bookCompositeService;

    @GetMapping("/product/{productId}")
    public BookComposite getBookComposite(@PathVariable Long productId) {
        return bookCompositeService.getCompositeProduct(productId);
    }

    // Optional CRUD endpoints (depending on team requirements)
    @PostMapping("/product")
    public BookComposite createBookComposite(@RequestBody BookCompositeRequest request) {
        RestApiService.Product product = new RestApiService.Product();
        product.setName(request.getProductName());
        product.setPrice(request.getProductPrice());
        return bookCompositeService.createCompositeProduct(product, request.getReviews(), request.getRecommendations());
    }

    @PutMapping("/product/{productId}")
    public BookComposite updateBookComposite(@PathVariable Long productId, @RequestBody BookCompositeRequest request) {
        RestApiService.Product product = new RestApiService.Product();
        product.setName(request.getProductName());
        product.setPrice(request.getProductPrice());
        return bookCompositeService.updateCompositeProduct(productId, product, request.getReviews(), request.getRecommendations());
    }

    @DeleteMapping("/product/{productId}")
    public void deleteBookComposite(@PathVariable Long productId) {
        bookCompositeService.deleteCompositeProduct(productId);
    }
}

// Helper class for request body
class BookCompositeRequest {
    private String productName;
    private double productPrice;
    private List<RestApiService.Review> reviews;
    private List<RestApiService.Recommendation> recommendations;

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }
    public double getProductPrice() { return productPrice; }
    public void setProductPrice(double productPrice) { this.productPrice = productPrice; }
    public List<RestApiService.Review> getReviews() { return reviews; }
    public void setReviews(List<RestApiService.Review> reviews) { this.reviews = reviews; }
    public List<RestApiService.Recommendation> getRecommendations() { return recommendations; }
    public void setRecommendations(List<RestApiService.Recommendation> recommendations) { this.recommendations = recommendations; }
}