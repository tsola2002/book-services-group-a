package com.dee.service;

import com.dee.entity.BookComposite;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookCompositeService {
    @Autowired
    private RestApiService restApiService;

    public BookComposite getCompositeProduct(Long productId) {
        RestApiService.Product product = restApiService.getProduct(productId);
        List<RestApiService.Review> reviews = restApiService.getReviews(productId);
        List<RestApiService.Recommendation> recommendations = restApiService.getRecommendations(productId);

        if (product != null) {
            String[] reviewComments = reviews.stream()
                    .map(RestApiService.Review::getComment)
                    .toArray(String[]::new);
            String[] recTexts = recommendations.stream()
                    .map(RestApiService.Recommendation::getRecommendation)
                    .toArray(String[]::new);
            return new BookComposite(product.getId(), product.getName(), product.getPrice(), reviewComments, recTexts);
        }
        return null;
    }

    // Additional methods for CRUD operations (optional, depending on team requirements)
    public BookComposite createCompositeProduct(RestApiService.Product product, List<RestApiService.Review> reviews, List<RestApiService.Recommendation> recommendations) {
        RestApiService.Product createdProduct = restApiService.createProduct(product);
        reviews.forEach(review -> restApiService.createReview(review));
        recommendations.forEach(rec -> restApiService.createRecommendation(rec));
        return getCompositeProduct(createdProduct.getId());
    }

    public BookComposite updateCompositeProduct(Long productId, RestApiService.Product product, List<RestApiService.Review> reviews, List<RestApiService.Recommendation> recommendations) {
        restApiService.updateProduct(productId, product);
        reviews.forEach(review -> restApiService.updateReview(review.getId(), review));
        recommendations.forEach(rec -> restApiService.updateRecommendation(rec.getId(), rec));
        return getCompositeProduct(productId);
    }

    public void deleteCompositeProduct(Long productId) {
        restApiService.deleteProduct(productId);
        // Note: Deleting reviews and recommendations for this productId would require filtering, which depends on team implementation
    }
}