package com.dee.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class RestApiService {
    @Autowired
    private RestTemplate restTemplate;

    // Product Microservice (port 8081)
    public Product getProduct(Long productId) {
        String url = "http://book-services-group-a.onrender.com/api/v1/products" + productId;
        return restTemplate.getForObject(url, Product.class);
    }

    public Product createProduct(Product product) {
        String url = "http://book-services-group-a.onrender.com/api/v1/products/ID";
        return restTemplate.postForObject(url, product, Product.class);
    }

    public Product updateProduct(Long productId, Product product) {
        String url = "http://book-services-group-a.onrender.com/api/v1/products" + productId;
        restTemplate.put(url, product);
        return restTemplate.getForObject(url, Product.class);
    }

    public void deleteProduct(Long productId) {
        String url = "http://book-services-group-a.onrender.com/api/v1/products/ID" + productId;
        restTemplate.delete(url);
    }

    // Review Microservice (port 8082)
    public List<Review> getReviews(Long productId) {
        String url = "http://book-services-group-a-1.onrender.com/reviews/book/2" + productId;
        return restTemplate.getForObject(url, List.class);
    }

    public Review createReview(Review review) {
        String url = "http://book-services-group-a-1.onrender.com/reviews";
        return restTemplate.postForObject(url, review, Review.class);
    }

    public Review updateReview(Long reviewId, Review review) {
        String url = "http://book-services-group-a-1.onrender.com/reviews" + reviewId;
        restTemplate.put(url, review);
        return restTemplate.getForObject(url, Review.class);
    }

    public void deleteReview(Long reviewId) {
        String url = "http://book-services-group-a-1.onrender.com/reviews/1" + reviewId;
        restTemplate.delete(url);
    }

    // Recommendation Microservice (port 8083)
    public List<Recommendation> getRecommendations(Long productId) {
        String url = "http://recommendation-8-c47c.onrender.com/api/books" + productId;
        return restTemplate.getForObject(url, List.class);
    }
//put
    public Recommendation createRecommendation(Recommendation recommendation) {
        String url = "http://recommendation-8-c47c.onrender.com/api/books/1";
        return restTemplate.postForObject(url, recommendation, Recommendation.class);
    }
//post
    public Recommendation updateRecommendation(Long recommendationId, Recommendation recommendation) {
        String url = "http://recommendation-8-c47c.onrender.com/api/books" + recommendationId;
        restTemplate.put(url, recommendation);
        return restTemplate.getForObject(url, Recommendation.class);
    }



    public static class Product {
        private Long id;
        private String name;
        private double price;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public double getPrice() { return price; }
        public void setPrice(double price) { this.price = price; }
    }

    public static class Review {
        private Long id;
        private Long productId;
        private String comment;
        private int rating;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public Long getProductId() { return productId; }
        public void setProductId(Long productId) { this.productId = productId; }
        public String getComment() { return comment; }
        public void setComment(String comment) { this.comment = comment; }
        public int getRating() { return rating; }
        public void setRating(int rating) { this.rating = rating; }
    }

    public static class Recommendation {
        private Long id;
        private Long productId;
        private String recommendation;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public Long getProductId() { return productId; }
        public void setProductId(Long productId) { this.productId = productId; }
        public String getRecommendation() { return recommendation; }
        public void setRecommendation(String recommendation) { this.recommendation = recommendation; }
    }
}